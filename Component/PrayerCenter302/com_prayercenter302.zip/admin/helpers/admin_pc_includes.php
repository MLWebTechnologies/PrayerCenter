<?php
/*
*
* PrayerCenter Component
*
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
*
*/
defined( '_JEXEC' ) or die( 'Restricted access' );
global $pcConfig,$prayercenteradmin;
$lang = JFactory::getLanguage();
$lang->load( 'com_prayercenter', JPATH_SITE); 
$siteApp = &JFactory::getApplication( 'site' );
$siteTemplate = $siteApp->getTemplate();
$siteTemplateParams = $siteApp->getTemplate(true)->params;
if($siteTemplate === 'hathor') {
	$document = JFactory::getDocument();
	$document->addStyleSheet(JURI::base().'components/com_prayercenter/assets/css/prayercenteradmin.css');
	if($siteTemplateParams['colourChoice'] === ''){ 
		?><style type="text/css">
			.well {
				background-color: #f9fade !important;
			}
			.row-striped {
				background-color: #f9fade;
			}
		</style><?php
	} elseif($siteTemplateParams['colourChoice'] === 'highcontrast'){ 
		?><style type="text/css">
			.well {
				background-color: #163365 !important;
			}
			.row-striped {
				background-color: #163365;
				color: #fcff20 !important;
			}
			.row-striped .row:hover,
			.row-striped .row-fluid:hover {
				background-color: #10254a;
			}
			.row-striped .row:nth-child(odd),
			.row-striped .row-fluid:nth-child(odd) {
				background-color: #1c4181 !important;
			}
		</style><?php
	} elseif($siteTemplateParams['colourChoice'] === 'brown'){ 
		?><style type="text/css">
			.well {
				background-color: #d5c1b2 !important;
			}
			.row-striped {
				background-color: #d5c1b2;
			}
		</style><?php
	} elseif($siteTemplateParams['colourChoice'] === 'blue'){ 
		?><style type="text/css">
			.well {
				background-color: #b1c4db !important;
			}
			.row-striped {
				background-color: #b1c4db;
			}
		</style><?php
	}
}
require( JPATH_ADMINISTRATOR.'/components/com_prayercenter/helpers/admin_pc_class.php' );
$prayercenteradmin = new prayercenteradmin();
$pcParams = JComponentHelper::getParams('com_prayercenter');
$pcParamsArray = $pcParams->toArray();
foreach($pcParamsArray['params'] as $name => $value){
  $pcConfig[(string)$name] = (string)$value;
}
?>