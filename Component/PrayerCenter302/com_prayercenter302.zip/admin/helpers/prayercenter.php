  <?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_prayercenter
 *
 * @copyright   Copyright (C) 2005 - 2013 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die;
/**
 * Weblinks helper.
 *
 * @package     Joomla.Administrator
 * @subpackage  com_prayercenter
 * @since       1.6
 */
class PrayerCenterHelper extends JHelperContent
{
	public static $extension = 'com_prayercenter';
	/**
	 * Configure the Linkbar.
	 *
	 * @param   string	The name of the active view.
	 * @since   1.6
	 */
	public static function addSubmenu($vName = 'prayercenter')
	{
		JSubMenuHelper::addEntry(
			JText::_('CPanel'),
			'index.php?option=com_prayercenter',
			$vName == 'prayercenter'
		);
		JSubMenuHelper::addEntry(
			JText::_('Requests'),
			'index.php?option=com_prayercenter&view=managereq',
			$vName == 'managereq'
		);
		JSubMenuHelper::addEntry(
			JText::_('Subscribers'),
			'index.php?option=com_prayercenter&view=managesub',
			$vName == 'managesub'
		);
		JSubMenuHelper::addEntry(
			JText::_('Files'),
			'index.php?option=com_prayercenter&view=managefiles',
			$vName == 'managefiles'
		);
		JSubMenuHelper::addEntry(
			JText::_('Devotionals'),
			'index.php?option=com_prayercenter&view=managedevotions',
			$vName == 'managedevotions'
		);
		JSubMenuHelper::addEntry(
			JText::_('Links'),
			'index.php?option=com_prayercenter&view=managelink',
			$vName == 'managelink'
		);
		JSubMenuHelper::addEntry(
			JText::_('Categories'),
			'index.php?option=com_categories&extension=com_prayercenter',
			$vName == 'categories'
		);
		if ($vName == 'categories')
		{
			JToolbarHelper::title(
				JText::sprintf('COM_CATEGORIES_CATEGORIES_TITLE', JText::_('com_prayercenter')),
				'prayercenter-categories');
		}
	}
}