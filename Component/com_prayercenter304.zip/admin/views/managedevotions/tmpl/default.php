<?php
/**
* PrayerCenter Component for Joomla
* By Mike Leeper
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
*
*/
// no direct access
defined('_JEXEC') or die('Restricted access');
global $prayercenteradmin;
JHtml::_('bootstrap.tooltip');
JHtml::_('behavior.multiselect');
JHtml::_('formbehavior.chosen', 'select');
$user		= JFactory::getUser();
$userId		= $user->get('id');
$listOrder	= $this->escape($this->state->get('list.ordering'));
$listDirn	= $this->escape($this->state->get('list.direction'));
$canOrder	= $user->authorise('core.edit.state', 'com_prayercenter.managedevotions');
$saveOrder	= $listOrder == 'a.ordering';
if ($saveOrder)
{
	$saveOrderingUrl = 'index.php?option=com_prayercenter&task=devs.saveOrderAjax&tmpl=component';
	JHtml::_('sortablelist.sortable', 'pcdevsList', 'adminForm', strtolower($listDirn), $saveOrderingUrl);
}
$sortFields = $this->getSortFields();
?>
<script type="text/javascript">
	Joomla.orderTable = function() {
		table = document.getElementById("sortTable");
		direction = document.getElementById("directionTable");
		order = table.options[table.selectedIndex].value;
		if (order != '<?php echo $listOrder; ?>') {
			dirn = 'asc';
		} else {
			dirn = direction.options[direction.selectedIndex].value;
		}
		Joomla.tableOrdering(order, dirn, 'manage_dev');
	}
</script>
<?php
$siteApp = JFactory::getApplication( 'site' );
$siteTemplate = $siteApp->getTemplate();
if($siteTemplate === 'hathor') {
	echo '<style type="text/css">.row-striped,
.table-striped,.row-fluid {
	font-size: 14px !important;	line-height: 2.2em;
}
</style>';
}?>
  <form action="<?php echo JRoute::_('index.php?option=com_prayercenter&view=managedevotions'); ?>" method="post" name="adminForm" id="adminForm">
<?php if (!empty( $this->sidebar)) : ?>
	<div id="j-sidebar-container" class="span2">
		<?php echo $this->sidebar; ?>
	</div>
	<div id="j-main-container" class="span12">
<?php else : ?>
	<div id="j-main-container">
<?php endif;?>
		<div id="filter-bar" class="btn-toolbar">
			<div class="filter-search btn-group pull-left">
				<label for="filter_search" class="element-invisible"><?php echo JText::_('COM_PRAYERCENTER_FILTER_SEARCH_DESC');?></label>
				<input type="text" name="filter_search" id="filter_search" placeholder="<?php echo JText::_('COM_PRAYERCENTER_SEARCH'); ?>" value="<?php echo $this->escape($this->state->get('filter.search')); ?>" title="<?php echo JText::_('COM_PRAYERCENTER_SEARCH'); ?>" />
			</div>
			<div class="btn-group pull-left">
				<button class="btn hasTooltip" type="submit" title="<?php echo JText::_('JSEARCH_FILTER_SUBMIT'); ?>"><i class="icon-search"></i></button>
				<button class="btn hasTooltip" type="button" title="<?php echo JText::_('JSEARCH_FILTER_CLEAR'); ?>" onclick="document.id('filter_search').value='';this.form.submit();"><i class="icon-remove"></i></button>
			</div>
			<div class="btn-group pull-right hidden-phone">
				<label for="limit" class="element-invisible"><?php echo JText::_('JFIELD_PLG_SEARCH_SEARCHLIMIT_DESC');?></label>
				<?php echo $this->pagination->getLimitBox(); ?>
			</div>
			<div class="btn-group pull-right hidden-phone">
				<label for="directionTable" class="element-invisible"><?php echo JText::_('JFIELD_ORDERING_DESC');?></label>
				<select name="directionTable" id="directionTable" class="input-medium" onchange="Joomla.orderTable()">
					<option value=""><?php echo JText::_('JFIELD_ORDERING_DESC');?></option>
					<option value="asc" <?php if ($listDirn == 'asc') echo 'selected="selected"'; ?>><?php echo JText::_('JGLOBAL_ORDER_ASCENDING');?></option>
					<option value="desc" <?php if ($listDirn == 'desc') echo 'selected="selected"'; ?>><?php echo JText::_('JGLOBAL_ORDER_DESCENDING');?></option>
				</select>
			</div>
			<div class="btn-group pull-right">
				<label for="sortTable" class="element-invisible"><?php echo JText::_('JGLOBAL_SORT_BY');?></label>
				<select name="sortTable" id="sortTable" class="input-medium" onchange="Joomla.orderTable()">
					<option value=""><?php echo JText::_('JGLOBAL_SORT_BY');?></option>
					<?php echo JHtml::_('select.options', $sortFields, 'value', 'text', $listOrder);?>
				</select>
			</div>
		</div>
		<div class="clearfix"> </div>
		<table class="table table-striped" id="pcdevsList">
	   <thead>
    		<tr>
					<th width="1%" class="nowrap center hidden-phone">
						<?php echo JHtml::_('grid.sort', '<i class="icon-menu-2"></i>', 'a.ordering', $listDirn, $listOrder, 'manage_dev', 'asc', 'JGRID_HEADING_ORDERING'); ?>
					</th>
					<th width="1%" class="hidden-phone">
						<input type="checkbox" name="checkall-toggle" value="" title="<?php echo JText::_('JGLOBAL_CHECK_ALL'); ?>" onclick="Joomla.checkAll(this)" />
					</th>
					<th class="title">
						<?php echo JHTML::_('grid.sort',   'Name', 'a.name', $listDirn, $listOrder, 'manage_dev' ); ?>
					</th>
					<th class="nowrap hidden-phone">
						<?php echo JHTML::_('grid.sort',   'Feed', 'a.feed', $listDirn, $listOrder, 'manage_dev' ); ?>
					</th>
					<th class="nowrap hidden-phone">
						<?php echo JHTML::_('grid.sort',   'Category', 'a.category', $listDirn, $listOrder, 'manage_dev' ); ?>
					</th>
					<th class="nowrap center hidden-phone" width="5%">
						<?php echo JHTML::_('grid.sort',   'Published', 'a.published', $listDirn, $listOrder, 'manage_dev' ); ?>
					</th>
    			<th width="1%" class="nowrap center hidden-phone">
    				<?php echo JHTML::_('grid.sort',  'JGRID_HEADING_ID', 'a.id', $listDirn, $listOrder, 'manage_dev' ); ?>
    			</th>
  		</tr></thead>
			<tfoot>
				<tr>
					<td colspan="7">
						<?php echo $this->pagination->getListFooter(); ?>
					</td>
				</tr>
			</tfoot>
			<tbody>
		<?php
		foreach ($this->items as $i => $item) {
			$ordering   = ($listOrder == 'a.ordering');
			$canCheckin = $user->authorise('core.manage', 'com_checkin') || $item->checked_out == $user->get('id') || $item->checked_out == 0;
			$canChange  = true;//$user->authorise('core.edit.state', 'com_prayercenter.managedev.' . $item->catid) && $canCheckin;
			?>
				<tr class="row<?php echo $i % 2; ?>" sortable-group-id="<?php echo md5($item->catid); ?>">
					<td class="order nowrap center hidden-phone">
					<?php if ($canChange) :
						$disableClassName = '';
						$disabledLabel	  = '';
						if (!$saveOrder) :
							$disabledLabel    = JText::_('JORDERINGDISABLED');
							$disableClassName = ' inactive tip-top';
						endif; ?>
						<span class="sortable-handler hasTooltip<?php echo $disableClassName;?>" title="<?php echo $disabledLabel;?>">
							<i class="icon-menu"></i>
						</span>
						<input type="text" style="display:none" name="order[]" size="5" value="<?php echo $item->ordering;?>" class="width-20 text-area-order " />
					<?php else : ?>
						<span class="sortable-handler inactive" >
							<i class="icon-menu"></i>
						</span>
					<?php endif; ?>
					</td>
				<td class="center hidden-phone" width="5">
        	<?php echo JHtml::_('grid.id', $i, $item->id); ?>
        </td>
				<td class="center hidden-phone">
					<a href="#edit" onclick="return listItemTask('cb<?php echo $i; ?>','editdevotion')">
						<?php echo stripslashes($this->escape($item->name)); ?></a></span></td>
					<?php if ($item->checked_out) : ?><br />
						<?php echo JHtml::_('jgrid.checkedout', $i, $item->editor, $item->checked_out_time, 'manage_dev.', $canCheckin);  ?>
          <?php endif; ?>
        </td>
        <td class="center hidden-phone"><?php echo JText::_($item->feed); ?></td>
        <td class="center hidden-phone"><?php echo JText::_($item->category_title); ?></td>
      <?php
			$publishimg = '';
      $publishimg[] = '<a class="btn btn-micro active" rel="tooltip"';
			if ($item->published) {
  			$publishimg[] = ' href="javascript:void(0);" onclick="return listItemTask(\'cb'.$i.'\', \'prayercenter.unpublishdevotion\')"';
  			$publishimg[] = ' title="'.addslashes(htmlspecialchars(JText::_('Unpublish Devotion'))).'">';
  			$publishimg[] = '<i class="icon-publish">';
			} else {
  			$publishimg[] = ' href="javascript:void(0);" onclick="return listItemTask(\'cb'.$i.'\', \'prayercenter.publishdevotion\')"';
  			$publishimg[] = ' title="'.addslashes(htmlspecialchars(JText::_('Publish Devotion'))).'">';
  			$publishimg[] = '<i class="icon-unpublish">';
			} 
			$publishimg[] = '</i>';
			$publishimg[] = '</a>';
    ?>           		
    <td class="center hidden-phone"><?php echo implode($publishimg); ?>
		<td class="center hidden-phone">
			<?php echo (int)$item->id; ?>
		</td>
		</tr>
  <?php
  }
  ?>
  </tbody>
		</table>
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="boxchecked" value="0" />
		<input type="hidden" name="filter_order" value="<?php echo $listOrder; ?>" />
		<input type="hidden" name="filter_order_Dir" value="<?php echo $listDirn; ?>" />
	<?php echo JHTML::_( 'form.token' ); ?>
	</form><br />
	<?php
  $prayercenteradmin->PCfooter();
?></div>