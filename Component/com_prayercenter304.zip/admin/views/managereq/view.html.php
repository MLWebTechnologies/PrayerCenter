<?php
/**
* PrayerCenter Component
* 
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
*
*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
class PrayerCenterViewManageReq extends JViewLegacy
{
	protected $items;
	protected $pagination;
	protected $state;
	public function display( $tpl = null)
	{
		$this->items		= $this->get('Items');
		$this->state		= $this->get('State');
		$this->pagination	= $this->get('Pagination');
		$this->filterForm    = $this->get('FilterForm');
		$this->activeFilters = $this->get('ActiveFilters');

		// Check for errors.
		if (count($errors = $this->get('Errors'))) {
			JError::raiseError(500, implode("\n", $errors));
			return false;
		}

		$this->sidebar = JHtmlSidebar::render();		
		$this->addToolbar();
		parent::display($tpl);
	}
	protected function addToolbar()
	{
		JToolbarHelper::title(JText::_('PrayerCenter - Manage Requests'),'list');
		JToolBarHelper::publishList("prayercenter.publish", 'Publish');
		JToolBarHelper::unpublishList("prayercenter.unpublish", 'Unpublish');
		JToolBarHelper::archiveList("prayercenter.archive", 'Archive');
		JToolBarHelper::unarchiveList("prayercenter.unarchive", 'Unarchive');
		JToolBarHelper::editList("edit", 'Edit');
		JToolBarHelper::deleteList( "Remove Request(s)?", "prayercenter.remove_req", 'Remove' );
		$cb = JToolBar::getInstance('toolbar');
		$cb->appendButton( 'confirm', 'Do you wish to proceed with the purging of old prayer requests?  Requests that are older than the request/archive retention settings will be removed from the PrayerCenter database table.', 'apply', 'Purge', 'prayercenter.purge', false);
		JHtmlSidebar::setAction('index.php?option=com_prayercenter');
	}
	protected function getSortFields()
	{
		return array(
			'a.requester' => JText::_('Requester'),
			'a.request' => JText::_('Request'),
			'a.publishstate' => JText::_('JPUBLISHED'),
			'a.archivestate' => JText::_('Archive State'),
			'a.displaystate' => JText::_('Display State'),
			'a.id' => JText::_('JGRID_HEADING_ID')
		);
	}
}
?>