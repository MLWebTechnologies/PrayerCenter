#
#<?php die('Forbidden.'); ?>
#Date: 2012-02-28 22:44:46 UTC
#Software: Joomla Platform 11.4.0 Stable [ Brian Kernighan ] 03-Jan-2012 00:00 GMT
#Fields: date time message