-- DROP TABLE `#__prayercenter`;
-- DROP TABLE `#__prayercenter_subscribe`;
-- DROP TABLE `#__prayercenter_devotions`;
-- DROP TABLE `#__prayercenter_links`;