<?php
/*
 * PrayerCenter Component
 *
 * @copyright   Copyright (C) 2005 - 2018 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die( 'Restricted access' );

class PrayerCenterModelManageReq extends JModelList{	

/**	 * Constructor	 *	 * @since 1.6	 */	
function __construct()	{
	if (empty($config['filter_fields'])) {
		$config['filter_fields'] = array(
		'id', 'a.id',
		'requesterid', 'a.requesterid',
		'requester', 'a.requester',
		'request', 'a.request',
		'date', 'a.date',
		'time', 'a.time',
		'publishstate', 'a.publishstate',
		'archivestate', 'a.archivestate',
		'displaystate', 'a.displaystate',
		'sendto', 'a.sendto',
		'email', 'a.email',
		'adminsendto', 'a.adminsendto',
		'checked_out_time', 'a.checked_out_time',
		'checked_out', 'a.checked_out',
		'sessionid', 'a.sessionid',
		'title', 'a.title',
		'topic', 'a.topic',
		'hits', 'a.hits'
		);
	}		
	parent::__construct($config);
}	

protected function getStoreId($id = ''){
	// Compile the store id.
	$id .= ':' . $this->getState('filter.search');
	$id .= ':' . $this->getState('filter.published');
	return parent::getStoreId($id);
}	

/**
 * Method to auto-populate the model state.
 *
 * Note. Calling getState in this method will result in recursion.
 *
 * @param   string  $ordering   An optional ordering field.
 * @param   string  $direction  An optional direction (asc|desc).
 *
 * @return  void
 *
 * @since   1.6
 */
protected function populateState($ordering = 'a.id', $direction = 'desc')	{
	// Load the filter state.
	$this->setState('filter.search', $this->getUserStateFromRequest($this->context . '.filter.search', 'filter_search', '', 'string'));
	$this->setState('filter.published', $this->getUserStateFromRequest($this->context . '.filter.published', 'filter_published', '', 'string'));

	// List state information.		
	parent::populateState($ordering, $direction);
}	
	
protected function getListQuery()	{
	// Create a new query object.
	$db		= $this->getDbo();
	$query	= $db->getQuery(true);
	$user	= JFactory::getUser();

	// Select the required fields from the table.
	$query->select(	
		$this->getState(
			'list.select',
			'a.id, a.requesterid,a.requester, a.request, a.date, a.time,' .
			'a.publishstate, a.archivestate, a.displaystate, a.sendto, a.email, a.adminsendto,' .
			'a.checked_out_time, a.checked_out, a.sessionid, a.title, a.topic, a.hits'
		)
	);		
	$query->select("DATE_FORMAT(CONCAT_WS(' ',a.date,a.time),'%Y-%m-%d %T') AS datetime");
	$query->from('#__prayercenter AS a');

	// Join over the users for the checked out user.
	$query->select('uc.name AS editor');
	$query->join('LEFT', '#__users AS uc ON uc.id=a.checked_out');

	// Filter by published state
	$published = $this->getState('filter.publishstate');
	if (is_numeric($published)) {
		$query->where('a.publishstate = ' . (int) $published);
	}
	elseif ($published === '') {
		$query->where('(a.publishstate = 0 OR a.publishstate = 1)');
	}

	// Filter by search in name.
	$search = $this->getState('filter.search');
	if (!empty($search)) {
		if (stripos($search, 'id:') === 0) {
			$query->where('a.id = '.(int) substr($search, 3));
		}
		elseif (stripos($search, 'name:') === 0) {
			$search = $db->Quote('%'.$db->escape(substr($search, 7), true).'%');
			$query->where('(uc.name LIKE '.$search.' OR uc.username LIKE '.$search.')');
		}
		elseif (stripos($search, 'request:') === 0) {
			$search = $db->Quote('%'.$db->escape($search, true).'%');
			$query->where('(a.request LIKE '.$search.')');
		}
		elseif (stripos($search, 'email:') === 0) {
			$search = $db->Quote('%'.$db->escape($search, true).'%');
			$query->where('(a.email LIKE '.$search.')');
		}
		elseif (stripos($search, 'requester:') === 0) {
			$search = $db->Quote('%'.$db->escape($search, true).'%');
			$query->where('(a.requester LIKE '.$search.')');
		}
	}

	// Add the list ordering clause.
	$orderCol  = $this->state->get('list.ordering', 'a.ID');
	$orderDirn = $this->state->get('list.direction', 'DESC');

	$query->order($db->escape($orderCol . ' ' . $orderDirn));

	return $query;
}

	/**	 * Method to checkin a row.	 *
	* @param   integer  $pk  The numeric id of the primary key.	 *
	* @return  boolean  False on failure or error, true otherwise.	 *
	* @since   12.2	 */	

	public function checkin($pk = null)	{
		// Only attempt to check the row in if it exists.
		if ($pk)
		{
			$user = JFactory::getUser();
			// Get an instance of the row to checkin.
			$table = $this->getTable('PrayerCenter','Table');
			if (!$table->load())
				{
					$this->setError($table->getError());
					return false;
				}
			// Check if this is the user having previously checked out the row.
			if ($table->checked_out > 0 && $table->checked_out != $user->get('id') && !$user->authorise('core.admin', 'com_checkin'))
				{
					$this->setError(JText::_('JLIB_APPLICATION_ERROR_CHECKIN_USER_MISMATCH'));
					return false;
				}
			// Attempt to check the row in.
			if (!$table->checkin($pk))
				{
					$this->setError($table->getError());
					return false;
				}
			}
			return true;
	}
}