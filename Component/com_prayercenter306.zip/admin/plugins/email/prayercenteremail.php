<?php
/**
 * @Component - PrayerCenter
 * @Plugin - Prayer request email
 * @copyright Copyright (C) MLWebtechnologies
 * @license GNU/GPL
 */
defined('_JEXEC') or die('Restricted access');
class plgSystemPrayerCenterEmail extends JPlugin {

  public function __construct(&$subject, $config){
	parent::__construct($subject, $config);
  }

  public function onAfterRoute(){                   
	require_once( JPATH_ROOT."/components/com_prayercenter/helpers/pc_email_class.php" );
	$prayercenteremailplg = new prayercenteremail();
    $prayercenteremailplg->pcEmailTask('PCadmin_email_notification');
    $prayercenteremailplg->pcEmailTask('PCemail_notification');
  }
}
?>