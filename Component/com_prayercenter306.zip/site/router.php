<?php
/**
 * Routing class from com_prayercenter
 *
 * @since  3.0.5
 */
class PrayercenterRouter extends JComponentRouterBase
{
	/**
	 * Build the route for the com_prayercenter component
	 *
	 * @param   array  &$query  An array of URL arguments
	 *
	 * @return  array  The URL arguments to use to assemble the subsequent URL.
	 *
	 * @since   3.0.5
	 */
	public function build(&$query)
	{
		$segments = array();
		if (isset($query['id']) && strpos($query['id'], ':')) {
			list($query['id'], $query['alias']) = explode(':', $query['id'], 2);
		}
		if (isset($query['task']))
		{
			$segments[] = $query['task'];
			unset($query['task']);
		}
		if (isset($query['id'])){ 
			if (isset($query['alias'])) {
				$query['id'] .= ':'.$query['alias'];
			}
			if(isset($query['view'])) {
				$segments[]	= $query['view'];
			}
			$segments[] = $query['id'].'-request';
			unset($query['view']);
			unset($query['id']);
		//		unset($query['alias']);
		}
		if(isset($query['pop'])){
			$segments[] = $query['pop'];
			unset($query['pop']);
		}
		if(isset($query['listtype'])){
		//    $segments[] = $query['listtype'];
		//    unset($query['listtype']);
		}
		if(isset($query['title'])){
		//    $segments[] = $query['title'];
		//    unset($query['title']);
		}
		if(isset($query['format'])){
		//    $segments[] = $query['format'];
		//    unset($query['format']);
		}
		if(isset($query['Itemid'])&&isset($query['alias'])){
			unset($query['Itemid']);
		}
		return $segments;
	}

	/**
	 * Parse the segments of a URL.
	 *
	 * @param   array  &$segments  The segments of the URL to parse.
	 *
	 * @return  array  The URL attributes to be used by the application.
	 *
	 * @since   3.0.5
	 */
	public function parse(&$segments)
	{
		$total = count($segments);
		$vars = array();

		for ($i = 0; $i < $total; $i++)
		{
			$segments[$i] = preg_replace('/-/', ':', $segments[$i], 1);
		}

		// View is always the first element of the array
		$count = count($segments);

		if($count)
		{
			$count--;
			$segment = array_shift($segments);
			$vars['task'] = $segment;
		}
		if($count)
		{
			$count--;
			$segment = array_shift($segments);
	//		if (is_numeric($segment)) {
		  $seg = explode(":",$segment);
			$vars['id'] = $seg[0];
	//		}
		}
		if($count)
		{
			$count--;
			$segment = array_shift($segments) ;
			if(is_numeric($segment)) {
			$vars['pop'] = $segment;
			}
		}
		if($count)
		{
			$count--;
			$segment = array_shift($segments) ;
			if(is_numeric($segment)) {
			$vars['listtype'] = $segment;
			}
		}
		if($count)
		{
			$count--;
			$segment = array_shift($segments) ;
			if(is_numeric($segment)) {
			$vars['title'] = $segment;
			}
		}
		if($count)
		{
			$count--;
			$segment = array_shift($segments) ;
			if(is_numeric($segment)) {
			$vars['format'] = $segment;
			}
		}
	//  $vars['Itemid'] = null;
		return $vars;
	}
}

/**
 * Build the route for the com_prayercenter component
 *
 * This function is a proxy for the new router interface
 * for old SEF extensions.
 *
 * @param   array  &$query  An array of URL arguments
 *
 * @return  array  The URL arguments to use to assemble the subsequent URL.
 *
 * @since   3.0.5
 * @deprecated  4.0  Use Class based routers instead
 */
function prayercenterBuildRoute(&$query)
{
	$router = new PrayerCenterRouter;

	return $router->build($query);
}

/**
 * Parse the segments of a URL.
 *
 * This function is a proxy for the new router interface
 * for old SEF extensions.
 *
 * @param   array  $segments  The segments of the URL to parse.
 *
 * @return  array  The URL attributes to be used by the application.
 *
 * @since   3.0.5
 * @deprecated  4.0  Use Class based routers instead
 */
function prayercenterParseRoute($segments)
{
	$router = new PrayerCenterRouter;

	return $router->parse($segments);
}
